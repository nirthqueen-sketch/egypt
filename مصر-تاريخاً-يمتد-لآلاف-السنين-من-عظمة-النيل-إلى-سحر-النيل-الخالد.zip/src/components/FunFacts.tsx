import { motion } from "motion/react";
import { Lightbulb, CheckCircle } from "lucide-react";

export function FunFacts() {
  const facts = [
    {
      title: "أقدم هرم",
      text: "هرم سقارة المدرج هو أقدم بناء حجري ضخم في التاريخ، بناه المهندس إيمحوتب للملك زوسر.",
      icon: <CheckCircle className="text-egypt-gold" />
    },
    {
      title: "نظام التقويم",
      text: "المصريون القدماء هم أول من اخترعوا تقويماً مكوناً من 365 يوماً في السنة.",
      icon: <Lightbulb className="text-egypt-gold" />
    },
    {
      title: "أول معاهدة سلام",
      text: "شهدت مصر توقيع أول معاهدة سلام موثقة في التاريخ بين رمسيس الثاني والحيثيين.",
      icon: <CheckCircle className="text-egypt-gold" />
    }
  ];

  return (
    <section className="py-20 bg-hieroglyphs relative overflow-hidden backdrop-brightness-95">
      <div className="max-w-6xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <span className="text-egypt-gold font-bold uppercase tracking-widest text-sm mb-2 block">معلومات قد لا تعرفها</span>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-egypt-blue">حقائق مذهلة عن مصر</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {facts.map((fact, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              whileHover={{ scale: 1.05 }}
              className="bg-white/80 backdrop-blur-sm p-8 rounded-[32px] border border-white shadow-xl flex flex-col items-center text-center group"
            >
              <div className="w-12 h-12 bg-egypt-gold/10 rounded-2xl flex items-center justify-center mb-6 transition-colors group-hover:bg-egypt-gold group-hover:text-white">
                {fact.icon}
              </div>
              <h3 className="text-xl font-bold text-egypt-blue mb-4">{fact.title}</h3>
              <p className="text-neutral-600 leading-relaxed font-light">
                {fact.text}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-egypt-gold/30 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-egypt-gold/30 to-transparent" />
    </section>
  );
}
