import { motion } from "motion/react";
import { ArrowDown } from "lucide-react";

export function Hero() {
  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{ 
          backgroundImage: `url('https://images.unsplash.com/photo-1572252009286-268acec5ca0a?q=80&w=2070&auto=format&fit=crop')`,
          filter: 'brightness(0.4)'
        }}
      />
      
      <div className="relative z-10 text-center px-4 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-serif font-bold text-white mb-8 leading-[1.3] text-center max-w-5xl mx-auto drop-shadow-2xl">
            مصر تاريخاً يمتد لآلاف السنين من عظمة النيل إلى سحر النيل الخالد
          </h1>
          <p className="text-lg md:text-xl text-neutral-300 mb-12 leading-relaxed font-light max-w-3xl mx-auto">
            انطلق في رحلة فضائية عبر الزمن، استكشف المدن، اختر العصور، واكتشف الأسرار التي شكلت وجه التاريخ.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <a 
              href="#map"
              className="px-8 py-4 bg-egypt-gold text-neutral-900 font-bold rounded-full transition-transform hover:scale-105 active:scale-95"
            >
              ابدأ الاستكشاف
            </a>
            <a 
              href="#quiz"
              className="px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-full transition-all hover:bg-white/10"
            >
              اختبر معلوماتك
            </a>
          </div>
        </motion.div>
      </div>

      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white opacity-50"
      >
        <ArrowDown size={32} />
      </motion.div>
    </section>
  );
}
