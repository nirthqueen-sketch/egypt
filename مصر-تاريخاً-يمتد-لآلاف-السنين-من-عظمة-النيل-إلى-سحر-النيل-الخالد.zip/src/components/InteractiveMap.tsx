import { motion, AnimatePresence } from "motion/react";
import React, { useState } from "react";
import { governorates, CityInfo, EraHistory } from "../data/egyptData";
import { Info, MapPin, Image as ImageIcon, Fish, Leaf, Pyramid, Landmark, Building, ChevronRight, History } from "lucide-react";

type MapFlow = 'map' | 'ask_city' | 'select_city' | 'select_era' | 'display_info';

export function InteractiveMap() {
  const [selectedGovId, setSelectedGovId] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState<MapFlow>('map');
  const [selectedCity, setSelectedCity] = useState<CityInfo | null>(null);
  const [selectedEra, setSelectedEra] = useState<EraHistory | null>(null);

  const govData = selectedGovId ? governorates[selectedGovId] : null;

  const handleGovClick = (id: string) => {
    setSelectedGovId(id);
    setSelectedCity(null);
    setSelectedEra(null);
    setCurrentStep('ask_city');
  };

  const resetFlow = () => {
    setSelectedGovId(null);
    setSelectedCity(null);
    setSelectedEra(null);
    setCurrentStep('map');
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'fish': return <Fish size={24} />;
      case 'olive': return <Leaf size={24} />;
      case 'pyramid': return <Pyramid size={24} />;
      case 'islamic': return <Landmark size={24} />;
      case 'monument': return <History size={24} />;
      default: return <MapPin size={24} />;
    }
  };

  return (
    <section id="map" className="py-20 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-serif font-bold text-egypt-blue mb-4">عين على مصر من الفضاء</h2>
        <div className="w-24 h-1 bg-egypt-gold mx-auto mb-6" />
        <p className="text-neutral-600 max-w-2xl mx-auto text-lg">
          استكشف المدن والعصور التاريخية بلمسة واحدة. الخريطة الآن تعكس ميزات كل محافظة.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8 items-stretch h-full">
        {/* Satellite Map Display */}
        <div className="relative bg-[#0b1a2d] rounded-[40px] shadow-2xl overflow-hidden p-6 min-h-[600px] flex items-center justify-center satellite-glow border-4 border-neutral-800">
           {/* Static Decorative Map Layers */}
           <div className="absolute inset-0 opacity-20 pointer-events-none">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_#000_100%)]"></div>
              <div className="w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
           </div>

           <svg
            viewBox="0 0 500 600"
            className="w-full h-full max-w-[450px] drop-shadow-[0_0_15px_rgba(212,175,55,0.4)] relative z-10"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Egypt Stylized Outline - Satellite Look */}
            <path
              d="M50 50 L450 50 L480 500 L400 580 L100 580 L20 500 Z"
              className="fill-[#14263b] stroke-neutral-700 stroke-[3]"
            />
            {/* Nile River - Glowing Cyan */}
            <path
              d="M320 600 Q350 450 300 350 T310 50"
              className="stroke-[#00f2ff] stroke-[10] fill-none opacity-40 blur-[2px]"
            />
             <path
              d="M320 600 Q350 450 300 350 T310 50"
              className="stroke-[#00c8ff] stroke-[4] fill-none"
            />
            
            {/* Custom Map Points per Governorates */}
            <IconMapPoint x={280} y={70} id="alexandria" label="الإسكندرية" active={selectedGovId === 'alexandria'} onClick={() => handleGovClick('alexandria')} icon={getIcon('fish')} />
            <IconMapPoint x={340} y={150} id="cairo" label="القاهرة" active={selectedGovId === 'cairo'} onClick={() => handleGovClick('cairo')} icon={getIcon('islamic')} />
            <IconMapPoint x={325} y={170} id="giza" label="الجيزة" active={selectedGovId === 'giza'} onClick={() => handleGovClick('giza')} icon={getIcon('pyramid')} />
            <IconMapPoint x={430} y={150} id="sinai" label="سيناء" active={selectedGovId === 'sinai'} onClick={() => handleGovClick('sinai')} icon={getIcon('olive')} />
            <IconMapPoint x={370} y={380} id="luxor" label="الأقصر" active={selectedGovId === 'luxor'} onClick={() => handleGovClick('luxor')} icon={getIcon('monument')} />
          </svg>
        </div>

        {/* Dynamic Interaction Panel */}
        <div className="relative h-full min-h-[600px] flex flex-col">
          <AnimatePresence mode="wait">
            {currentStep === 'map' && (
              <motion.div
                key="step-map"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="h-full bg-white/5 border-2 border-dashed border-white/20 rounded-[40px] flex flex-col items-center justify-center p-12 text-center"
              >
                <div className="w-24 h-24 bg-white/10 rounded-full shadow-lg flex items-center justify-center mb-8 text-egypt-gold border border-white/10">
                  <MapPin size={48} />
                </div>
                <h3 className="text-2xl font-serif font-bold text-white mb-4">اختر منطقتك المفضلة</h3>
                <p className="text-neutral-400 text-lg">تحرك فوق الأيقونات المميزة لاستكشاف سر كل محافظة وشهرتها</p>
              </motion.div>
            )}

            {currentStep === 'ask_city' && govData && (
              <motion.div
                key="step-ask"
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                className="bg-white rounded-[40px] shadow-2xl p-10 h-full flex flex-col items-center justify-center text-center border border-egypt-gold/20"
              >
                <div className="w-20 h-20 bg-egypt-gold/10 rounded-full flex items-center justify-center mb-6 text-egypt-gold">
                   <Building size={40} />
                </div>
                <h3 className="text-3xl font-serif font-bold text-egypt-blue mb-2">أهلاً بك في {govData.name}</h3>
                <p className="text-egypt-gold font-bold mb-6">تشتهر بـ: {govData.famousFor}</p>
                <p className="text-neutral-600 mb-10 text-lg">هل ترغب في تحديد مدينة معينة داخل المحافظة لاستكشاف تاريخها عبر العصور؟</p>
                <div className="flex gap-4 w-full max-w-xs">
                  <button 
                    onClick={() => setCurrentStep('select_city')}
                    className="flex-1 bg-egypt-blue text-white py-4 rounded-2xl font-bold hover:bg-egypt-blue/90 shadow-lg"
                  >
                    نعم، أريد
                  </button>
                  <button 
                    onClick={() => setCurrentStep('display_info')}
                    className="flex-1 bg-neutral-100 text-neutral-600 py-4 rounded-2xl font-bold hover:bg-neutral-200"
                  >
                    لا، النبذة العامة
                  </button>
                </div>
                <button onClick={resetFlow} className="mt-8 text-neutral-400 font-bold flex items-center gap-2 hover:text-egypt-gold transition-colors">
                  <ChevronRight size={18} /> العودة للخريطة
                </button>
              </motion.div>
            )}

            {currentStep === 'select_city' && govData && (
              <motion.div
                key="step-select-city"
                 initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                className="bg-white rounded-[40px] shadow-2xl p-10 h-full flex flex-col"
              >
                 <h3 className="text-2xl font-serif font-bold text-egypt-blue mb-8 border-b pb-4">اختر المدينة من {govData.name}</h3>
                 <div className="grid gap-4 flex-grow overflow-y-auto pr-2">
                    {govData.cities.map((city, idx) => (
                      <button 
                        key={idx}
                        onClick={() => { setSelectedCity(city); setCurrentStep('select_era'); }}
                        className="flex items-center justify-between p-6 bg-neutral-50 rounded-2xl border border-neutral-100 hover:border-egypt-gold hover:bg-egypt-gold/5 transition-all text-right group"
                      >
                         <span className="text-xl font-bold text-egypt-blue">{city.name}</span>
                         <ChevronRight className="text-egypt-gold group-hover:translate-x-[-10px] transition-transform" />
                      </button>
                    ))}
                 </div>
                 <button onClick={() => setCurrentStep('ask_city')} className="mt-6 text-neutral-400 font-bold text-center">العودة للتساؤل السابق</button>
              </motion.div>
            )}

            {currentStep === 'select_era' && selectedCity && (
              <motion.div
                key="step-select-era"
                 initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                className="bg-white rounded-[40px] shadow-2xl p-10 h-full flex flex-col"
              >
                 <h3 className="text-2xl font-serif font-bold text-egypt-blue mb-8 border-b pb-4">عصور مدينة {selectedCity.name}</h3>
                 <div className="grid gap-4 flex-grow">
                    {Object.entries(selectedCity.eras).map(([key, era]) => {
                       const eraData = era as EraHistory;
                       return (
                         <button 
                           key={key}
                           onClick={() => { setSelectedEra(eraData); setCurrentStep('display_info'); }}
                           className="flex items-center gap-4 p-6 bg-egypt-sand/30 rounded-2xl border border-egypt-gold/20 hover:border-egypt-gold hover:bg-white transition-all text-right"
                         >
                            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-egypt-gold shadow-sm">
                               <History size={24} />
                            </div>
                            <span className="text-xl font-bold text-egypt-blue">{eraData.name}</span>
                         </button>
                       );
                    })}
                 </div>
                 <button onClick={() => setCurrentStep('select_city')} className="mt-6 text-neutral-400 font-bold text-center">العودة لاختيار المدينة</button>
              </motion.div>
            )}

            {currentStep === 'display_info' && govData && (
              <motion.div
                key="step-info"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -30 }}
                className="bg-white rounded-[40px] shadow-2xl border border-egypt-gold/10 h-full flex flex-col overflow-hidden"
              >
                <div className="relative h-56 overflow-hidden">
                  <img src={govData.imageUrl} alt={govData.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                  <div className="absolute bottom-6 right-8">
                     <h3 className="text-3xl font-serif font-bold text-white">{selectedCity ? `${selectedCity.name} - ${selectedEra?.name}` : govData.name}</h3>
                     <p className="text-egypt-gold font-bold">{govData.famousFor}</p>
                  </div>
                </div>

                <div className="p-8 flex-grow">
                   <div className="mb-8">
                      <h4 className="flex items-center gap-2 text-egypt-blue font-black mb-4">
                        <Info size={20} className="text-egypt-gold" />
                        <span>سر التاريخ</span>
                      </h4>
                      <p className="text-neutral-600 leading-relaxed text-lg">
                        {selectedEra ? selectedEra.description : govData.history}
                      </p>
                   </div>

                   {!selectedCity && (
                     <div>
                        <h4 className="flex items-center gap-2 text-egypt-blue font-black mb-4">
                          <ImageIcon size={20} className="text-egypt-gold" />
                          <span>أهم المعالم</span>
                        </h4>
                        <div className="flex flex-wrap gap-2">
                           {govData.landmarks.map((l, i) => (
                             <span key={i} className="px-4 py-2 bg-neutral-100 rounded-full text-sm font-bold text-neutral-600">{l}</span>
                           ))}
                        </div>
                     </div>
                   )}
                </div>

                <div className="p-8 border-t border-neutral-100 flex gap-4">
                   <button onClick={resetFlow} className="flex-1 bg-egypt-blue text-white py-3 rounded-xl font-bold">العودة للخريطة</button>
                   {selectedCity && <button onClick={() => setCurrentStep('select_era')} className="flex-1 bg-neutral-100 text-neutral-600 py-3 rounded-xl font-bold">عصر آخر</button>}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

function IconMapPoint({ x, y, id, label, active, onClick, icon }: { x: number, y: number, id: string, label: string, active: boolean, onClick: () => void, icon: React.ReactNode }) {
  return (
    <g className="cursor-pointer group" onClick={onClick}>
      <circle cx={x} cy={y} r={active ? 32 : 28} className={`${active ? 'fill-egypt-gold' : 'fill-white/10'} transition-all group-hover:fill-white/20`} />
      <g className={`${active ? 'text-white' : 'text-egypt-gold'} transition-all group-hover:scale-110 origin-center`} style={{ transformBox: 'fill-box', transformOrigin: 'center' }}>
         <foreignObject x={x - 12} y={y - 12} width="24" height="24">
            <div className="flex items-center justify-center w-full h-full">
              {icon}
            </div>
         </foreignObject>
      </g>
      <text x={x} y={y + 45} textAnchor="middle" className={`text-[12px] font-bold ${active ? 'fill-egypt-gold' : 'fill-neutral-400'} select-none`} style={{ fontFamily: 'Cairo, sans-serif' }}>
        {label}
      </text>
    </g>
  );
}

