import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import { historyTimeline } from "../data/egyptData";
import { ChevronDown, ChevronUp, BookOpen } from "lucide-react";

export function HistoryTimeline() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  return (
    <section id="history" className="py-24 bg-white overflow-hidden">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-egypt-blue mb-4">خط زمن التاريخ المصري</h2>
          <div className="w-24 h-1 bg-egypt-gold mx-auto mb-6" />
          <p className="text-neutral-600 max-w-2xl mx-auto">رحلة عبر السنين تستعرض المحطات الكبرى في تاريخ مصر. اضغط على أي بطاقة لمعرفة تفاصيل أكثر ورؤية الصور.</p>
        </div>

        <div className="relative">
          {/* Vertical Line */}
          <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-1 bg-neutral-100 hidden md:block" />

          <div className="space-y-12">
            {historyTimeline.map((item, idx) => {
              const isExpanded = expandedIndex === idx;
              
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className={`relative flex flex-col md:flex-row items-center gap-8 ${
                    idx % 2 === 0 ? "md:flex-row-reverse" : ""
                  }`}
                >
                  {/* Dot */}
                  <div className={`absolute left-1/2 -translate-x-1/2 w-6 h-6 rounded-full border-4 border-white shadow-lg z-10 hidden md:block transition-colors duration-300 ${
                    isExpanded ? 'bg-egypt-blue scale-125' : 'bg-egypt-gold'
                  }`} />

                  <div className="flex-1 w-full md:w-auto">
                    <button
                      onClick={() => setExpandedIndex(isExpanded ? null : idx)}
                      className={`w-full bg-egypt-sand p-6 md:p-8 rounded-[32px] border border-neutral-100 shadow-sm transition-all duration-500 overflow-hidden text-right group ${
                        isExpanded ? "ring-2 ring-egypt-gold/50 shadow-xl" : "hover:shadow-md"
                      }`}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className={`transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}>
                          {isExpanded ? <ChevronUp className="text-egypt-gold" /> : <ChevronDown className="text-neutral-400 group-hover:text-egypt-gold" />}
                        </div>
                        <span className="inline-block px-4 py-1 bg-white text-egypt-gold rounded-full text-xs font-bold shadow-sm">
                          {item.date}
                        </span>
                      </div>

                      <h3 className="text-2xl font-serif font-bold text-egypt-blue mb-3">{item.period}</h3>
                      <p className="text-neutral-600 leading-relaxed font-light mb-4">
                        {item.description}
                      </p>

                      {!isExpanded && (
                        <div className="flex items-center gap-2 text-egypt-gold text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                          <BookOpen size={16} />
                          <span>اقرأ المزيد</span>
                        </div>
                      )}

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.4, ease: "easeInOut" }}
                            className="bg-white/50 rounded-2xl p-6 mt-6 border-t border-egypt-gold/20"
                          >
                            <div className="grid md:grid-cols-2 gap-6 items-center">
                              <div className="order-2 md:order-1">
                                <p className="text-neutral-700 leading-relaxed text-sm md:text-base">
                                  {item.details}
                                </p>
                              </div>
                              <div className="order-1 md:order-2">
                                <img 
                                  src={item.image} 
                                  alt={item.period} 
                                  className="w-full h-40 object-cover rounded-2xl shadow-md border-2 border-white"
                                  referrerPolicy="no-referrer"
                                />
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </button>
                  </div>

                  <div className="flex-1 hidden md:block" />
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
