import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import { quizQuestions } from "../data/egyptData";
import { CheckCircle2, XCircle, RotateCcw, Award } from "lucide-react";

export function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const handleOptionSelect = (idx: number) => {
    if (selectedOption !== null) return;
    
    setSelectedOption(idx);
    const correct = idx === quizQuestions[currentQuestion].correctAnswer;
    setIsCorrect(correct);
    if (correct) setScore(score + 1);

    setTimeout(() => {
      if (currentQuestion < quizQuestions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedOption(null);
        setIsCorrect(null);
      } else {
        setShowResult(true);
      }
    }, 1500);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedOption(null);
    setIsCorrect(null);
  };

  return (
    <section id="quiz" className="py-24 bg-egypt-blue text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-egypt-gold/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

      <div className="max-w-3xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-bold mb-4">اختبر معلوماتك</h2>
          <p className="text-white/70">هل أنت خبير في التاريخ المصري؟ أجب على الأسئلة التالية واكتشف ذلك!</p>
        </div>

        <div className="bg-white text-neutral-900 p-8 md:p-12 rounded-[40px] shadow-2xl">
          <AnimatePresence mode="wait">
            {!showResult ? (
              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex justify-between items-center mb-8">
                  <span className="text-sm font-bold text-egypt-gold uppercase tracking-widest">
                    السؤال {currentQuestion + 1} من {quizQuestions.length}
                  </span>
                  <div className="w-16 h-1 bg-neutral-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-egypt-gold transition-all duration-500" 
                      style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
                    />
                  </div>
                </div>

                <h3 className="text-2xl md:text-3xl font-bold mb-10 leading-tight">
                  {quizQuestions[currentQuestion].question}
                </h3>

                <div className="grid gap-4">
                  {quizQuestions[currentQuestion].options.map((option, idx) => {
                    let statusClass = "border-neutral-100 hover:border-egypt-gold";
                    let icon = null;

                    if (selectedOption === idx) {
                      if (isCorrect) {
                        statusClass = "border-green-500 bg-green-50 ring-2 ring-green-200";
                        icon = <CheckCircle2 className="text-green-500" size={20} />;
                      } else {
                        statusClass = "border-red-500 bg-red-50 ring-2 ring-red-200";
                        icon = <XCircle className="text-red-500" size={20} />;
                      }
                    } else if (selectedOption !== null && idx === quizQuestions[currentQuestion].correctAnswer) {
                      statusClass = "border-green-500 bg-green-50/50";
                    }

                    return (
                      <button
                        key={idx}
                        onClick={() => handleOptionSelect(idx)}
                        disabled={selectedOption !== null}
                        className={`flex items-center justify-between p-5 border-2 rounded-2xl transition-all font-bold text-right group ${statusClass}`}
                      >
                        <span className="text-lg">{option}</span>
                        {icon}
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-8"
              >
                <div className="w-24 h-24 bg-egypt-gold/10 text-egypt-gold rounded-full flex items-center justify-center mx-auto mb-8">
                  <Award size={48} />
                </div>
                <h3 className="text-4xl font-serif font-bold mb-4">إنتهى الاختبار!</h3>
                <p className="text-xl text-neutral-500 mb-8">
                  لقد أجبت بشكل صحيح على <span className="text-egypt-gold font-bold">{score}</span> من <span className="text-egypt-gold font-bold">{quizQuestions.length}</span> أسئلة.
                </p>

                <div className="p-8 bg-neutral-50 rounded-3xl mb-10">
                  <p className="text-lg font-bold text-egypt-blue mb-2">
                    {score === quizQuestions.length ? "أنت ملك التاريخ! إنجاز عظيم." : 
                     score >= quizQuestions.length / 2 ? "أحسنت! لديك معرفة جيدة بالتاريخ." : 
                     "بداية جيدة! يمكنك تعلم المزيد عن تاريخ مصر العظيم."}
                  </p>
                </div>

                <button
                  onClick={resetQuiz}
                  className="flex items-center gap-2 px-8 py-4 bg-egypt-blue text-white font-bold rounded-full mx-auto hover:bg-egypt-blue/90 transition-colors"
                >
                  <RotateCcw size={20} />
                  <span>حاول مرة أخرى</span>
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
