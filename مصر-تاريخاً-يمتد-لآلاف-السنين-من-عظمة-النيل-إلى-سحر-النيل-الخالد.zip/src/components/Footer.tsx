import React from "react";
import { MapPin, Phone, Mail, Instagram, Twitter, Facebook } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-neutral-900 text-white pt-20 pb-10 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-12 mb-16">
          <div className="space-y-6">
            <h3 className="text-3xl font-serif font-bold text-egypt-gold">مصر: مهد الحضارات</h3>
            <p className="text-neutral-400 leading-relaxed">
              منصة تعليمية تهدف إلى نشر الوعي بالتاريخ المصري العريق وجمال محافظات مصر من الإسكندرية إلى أسوان.
            </p>
            <div className="flex gap-4">
              <SocialIcon icon={<Facebook size={20} />} />
              <SocialIcon icon={<Twitter size={20} />} />
              <SocialIcon icon={<Instagram size={20} />} />
            </div>
          </div>

          <div className="space-y-6">
            <h4 className="text-xl font-bold">روابط سريعة</h4>
            <ul className="space-y-4 text-neutral-400">
              <li><a href="#" className="hover:text-egypt-gold transition-colors">الرئيسية</a></li>
              <li><a href="#map" className="hover:text-egypt-gold transition-colors">خريطة المحافظات</a></li>
              <li><a href="#history" className="hover:text-egypt-gold transition-colors">خط الزمن</a></li>
              <li><a href="#quiz" className="hover:text-egypt-gold transition-colors">اختبر معلوماتك</a></li>
            </ul>
          </div>

          <div className="space-y-6">
            <h4 className="text-xl font-bold">تواصل معنا</h4>
            <ul className="space-y-4 text-neutral-400">
              <li className="flex gap-3">
                <MapPin size={20} className="text-egypt-gold shrink-0 transition-transform hover:scale-110" />
                <span>القاهرة، جمهورية مصر العربية</span>
              </li>
              <li className="flex gap-3">
                <Phone size={20} className="text-egypt-gold shrink-0 transition-transform hover:scale-110" />
                <span>+20 123 456 789</span>
              </li>
              <li className="flex gap-3">
                <Mail size={20} className="text-egypt-gold shrink-0 transition-transform hover:scale-110" />
                <span>info@egypt-history.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10 text-center text-neutral-500 text-sm">
          <p>© {new Date().getFullYear()} مصر: مهد الحضارات. جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
}

function SocialIcon({ icon }: { icon: React.ReactNode }) {
  return (
    <a href="#" className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center transition-all hover:bg-egypt-gold hover:border-egypt-gold hover:text-neutral-900">
      {icon}
    </a>
  );
}
