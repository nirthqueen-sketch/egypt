export interface EraHistory {
  name: string;
  description: string;
}

export interface CityInfo {
  name: string;
  eras: Record<string, EraHistory>;
}

export interface GovernorateInfo {
  id: string;
  name: string;
  famousFor: string;
  iconType: 'fish' | 'olive' | 'pyramid' | 'monument' | 'islamic';
  history: string;
  landmarks: string[];
  imageUrl: string;
  cities: CityInfo[];
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
}

export const governorates: Record<string, GovernorateInfo> = {
  cairo: {
    id: "cairo",
    name: "القاهرة",
    famousFor: "العمارة الإسلامية",
    iconType: 'islamic',
    history: "تأسست القاهرة في عام 969 م على يد الفاطميين وهي قلب مصر النابض.",
    landmarks: ["قلعة صلاح الدين", "المتحف المصري"],
    imageUrl: "https://images.unsplash.com/photo-1572252009286-268acec5ca0a?q=80&w=600&auto=format&fit=crop",
    cities: [
      { 
        name: "حي القلعة", 
        eras: { 
          "الأيوبي": { name: "العصر الأيوبي", description: "بناء قلعة صلاح الدين لحماية القاهرة من الصليبيين." },
          "المملوكي": { name: "العصر المملوكي", description: "شهد بناء مسجد السلطان حسن، قمة العمارة الإسلامية." }
        } 
      },
      { 
        name: "الفرافسة", 
        eras: { 
          "الفاطمي": { name: "العصر الفاطمي", description: "تأسيس القاهرة والجامع الأزهر كمركز للعلم." }
        } 
      }
    ]
  },
  giza: {
    id: "giza",
    name: "الجيزة",
    famousFor: "الأهرامات",
    iconType: 'pyramid',
    history: "موطن أهرامات الجيزة العظيمة، أقدم عجائب الدنيا السبع.",
    landmarks: ["الأهرامات", "أبو الهول"],
    imageUrl: "https://images.unsplash.com/photo-1503177119275-0aa32b3a9368?q=80&w=600&auto=format&fit=crop",
    cities: [
      { 
        name: "هضبة الأهرام", 
        eras: { 
          "الفرعوني القديم": { name: "الدولة القديمة", description: "بناء الأهرامات الثلاثة (خوفو، خفرع، منهقرع) وبزوغ فجر الهندسة." } 
        } 
      },
      { 
        name: "سقارة", 
        eras: { 
          "الفرعوني المبكر": { name: "عصر الأسرات الأولى", description: "بناء الهرم المدرج (زوسر) وهو أول بناء حجري في التاريخ." } 
        } 
      }
    ]
  },
  alexandria: {
    id: "alexandria",
    name: "الإسكندرية",
    famousFor: "السمك والعروس",
    iconType: 'fish',
    history: "أسسها الإسكندر الأكبر عام 331 ق.م لتكون نافذة مصر على المتوسط.",
    landmarks: ["قلعة قايتباي", "مكتبة الإسكندرية"],
    imageUrl: "https://images.unsplash.com/photo-1568283046733-398327618994?q=80&w=600&auto=format&fit=crop",
    cities: [
        { 
          name: "منطقة الميناء", 
          eras: { 
            "اليوناني": { name: "العصر البطلمي", description: "عصر منارة الإسكندرية ومكتية الإسكندرية القديمة." },
            "الروماني": { name: "العصر الروماني", description: "بناء عمود السواري وانتشار الفلسفة السكندرية." }
          } 
        }
    ]
  },
  sinai: {
    id: "sinai",
    name: "سيناء",
    famousFor: "الزيتون والفيروز",
    iconType: 'olive',
    history: "أرض الأنبياء والمقدسات ومدخل مصر الشرقي.",
    landmarks: ["دير سانت كاترين", "جبل موسى"],
    imageUrl: "https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?q=80&w=600&auto=format&fit=crop",
    cities: [
      { 
        name: "سانت كاترين", 
        eras: { 
          "البيزنطي": { name: "العصر المسيحي", description: "بناء دير سانت كاترين بأمر من الإمبراطور جستنيان في القرن السادس." } 
        } 
      }
    ]
  },
  luxor: {
    id: "luxor",
    name: "الأقصر",
    famousFor: "الآثار والكنوز",
    iconType: 'monument',
    history: "مدينة المائة باب، تضم ثلث آثار العالم القديم.",
    landmarks: ["معبد الكرنك", "وادي الملوك"],
    imageUrl: "https://images.unsplash.com/photo-1599108600125-9711994b8860?q=80&w=600&auto=format&fit=crop",
    cities: [
        { 
          name: "طيبة الشرقية", 
          eras: { 
            "الفرعوني الحديث": { name: "الدولة الحديثة", description: "عصر الإمبراطورية المصرية الكبرى، عصر رمسيس الثاني وتوت عنخ آمون." } 
          } 
        }
    ]
  }
};

export const historyTimeline = [
  {
    period: "مصر القديمة (الفراعنة)",
    date: "3100 ق.م - 332 ق.م",
    description: "عصر بناة الأهرامات، والملوك العظام مثل رمسيس الثاني وتوت عنخ آمون.",
    details: "تميزت هذه الفترة بتوحيد القطرين على يد الملك مينا، وبناء عجائب الدنيا السبع. شهدت الدولة القديمة بناء الأهرامات، بينما شهدت الدولة الحديثة توسعاً إمبريالياً وبناء معابد الأقصر والكرنك. كانت الكتابة الهيروغليفية هي وسيلة التدوين الرئيسية.",
    image: "https://images.unsplash.com/photo-1503177119275-0aa32b3a9368?q=80&w=600&auto=format&fit=crop"
  },
  {
    period: "العصر اليوناني والروماني",
    date: "332 ق.م - 641 م",
    description: "دخول الإسكندر الأكبر مصر، وبناء مدينة الإسكندرية كمركز ثقافي عالمي.",
    details: "بعد وفاة الإسكندر، حكم البطالمة مصر وجعلوها منارة للعلم بفضل مكتبة الإسكندرية ومنارها الشهير. انتهى حكم البطالمة بوفاة كليوباترا السابعة لتصبح مصر ولاية رومانية ثم بيزنطية، وشهدت هذه الفترة انتشار المسيحية وبناء الأديرة العريقة.",
    image: "https://images.unsplash.com/photo-1568283046733-398327618994?q=80&w=600&auto=format&fit=crop"
  },
  {
    period: "العصر الإسلامي",
    date: "641 م - 1517 م",
    description: "فتح مصر على يد عمرو بن العاص وتأسيس الفسطاط ثم القاهرة.",
    details: "تحولت مصر لمركز للثقافة الإسلامية. تعاقبت عليها دول قوية مثل الطولونية والإخشيدية، ثم الفاطمية التي أسست القاهرة والأزهر، تلاها العصر الأيوبي بقيادة صلاح الدين الذي بنى القلعة، ثم عصر المماليك الذي شهد نهضة معمارية فريدة.",
    image: "https://images.unsplash.com/photo-1553913861-c0fddf2619ee?q=80&w=600&auto=format&fit=crop"
  },
  {
    period: "العصر الحديث والمعاصر",
    date: "1805 م - الآن",
    description: "من حكم محمد علي باشا وتأسيس مصر الحديثة إلى ثورة 1952 والجمهورية الحالية.",
    details: "بدأ محمد علي باشا في بناء جيش واقتصاد حديث. تم افتتاح قناة السويس عام 1869، تبعها الاحتلال البريطاني ثم استقلال مصر وثورة 1952 التي أسست الجمهورية. واليوم، تشهد مصر نهضة عمرانية كبرى وبناء العاصمة الإدارية الجديدة.",
    image: "https://images.unsplash.com/photo-1572252009286-268acec5ca0a?q=80&w=600&auto=format&fit=crop"
  }
];

export const quizQuestions: QuizQuestion[] = [
  {
    question: "من هو القائد الذي أسس مدينة الإسكندرية؟",
    options: ["عمرو بن العاص", "الإسكندر الأكبر", "محمد علي باشا", "صلاح الدين الأيوبي"],
    correctAnswer: 1
  },
  {
    question: "في أي عهد بُنيت أهرامات الجيزة العظيمة؟",
    options: ["الدولة الحديثة", "العصر الروماني", "الدولة القديمة", "العصر الفاطمي"],
    correctAnswer: 2
  },
  {
    question: "ما هي المدينة التي كانت تُعرف قديماً باسم 'طيبة'؟",
    options: ["أسوان", "القاهرة", "الإسكندرية", "الأقصر"],
    correctAnswer: 3
  },
  {
    question: "من هو مؤسس الدولة الفاطمية في مصر؟",
    options: ["جوهر الصقلي", "قطز", "الظاهر بيبرس", "أحمد بن طولون"],
    correctAnswer: 0
  }
];
