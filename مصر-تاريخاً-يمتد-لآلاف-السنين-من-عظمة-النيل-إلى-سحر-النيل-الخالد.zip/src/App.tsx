/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { InteractiveMap } from "./components/InteractiveMap";
import { HistoryTimeline } from "./components/HistoryTimeline";
import { FunFacts } from "./components/FunFacts";
import { Quiz } from "./components/Quiz";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-egypt-sand font-sans">
      <Navbar />
      <main>
        <Hero />
        
        {/* Welcome Text Section */}
        <section className="py-24 px-4 bg-white relative">
          <div className="max-w-4xl mx-auto text-center relative z-10">
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-egypt-blue mb-8 leading-tight">
              تاريخٌ ينبض بالحياة في كل شبرٍ من أرض مصر
            </h2>
            <p className="text-xl text-neutral-600 leading-relaxed font-light">
              ليست مصر مجرد بلدٍ على الخريطة، بل هي فجر الضمير الإنساني وأول من خطّ التاريخ على جدران المعابد. نحن ندعوك في هذه المنصة لتكتشف عظمة أجدادنا وتستلهم من حضارتهم التي ما زالت تُبهر العالم حتى اليوم.
            </p>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-egypt-gold/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        </section>

        <InteractiveMap />
        
        <FunFacts />

        <HistoryTimeline />
        <Quiz />
      </main>
      <Footer />
    </div>
  );
}
